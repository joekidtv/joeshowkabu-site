# Joe Show Kabu 公式サイト — 運用マニュアル

## ファイル構成
```
index.html         トップページ
lectures.html      レクチャーアーカイブ
about.html         Aboutページ
disclaimer.html    免責事項ページ
lectures.json      ← レクチャーのデータ(ここを編集)
news.json          ← NEWSのデータ(ここを編集)
assets/
  logo.png         公式ロゴ
  style.css        全ページ共通デザイン
  app.js           データ読み込み・描画
  thumbs/          サムネイル画像を入れる場所
```

## 公開方法(どちらか)
- **Netlify**: このフォルダごとドラッグ&ドロップするだけで公開
- **GitHub Pages**: このフォルダをリポジトリにpushし、Pagesを有効化

※ローカルのブラウザでindex.htmlを直接開くと、JSON読み込み(fetch)がブラウザの制限でブロックされる場合があります。正しく確認するには、上記のように公開するか、簡易サーバー(`python3 -m http.server`)を使ってください。

## 新しいレクチャーを追加するには
`lectures.json` の配列の**末尾**に、以下の形式で1件追記して保存するだけです。
トップの「最新レクチャー」とアーカイブの両方に自動で反映されます。

```json
{
  "id": "lecture-10",
  "number": "10",
  "title": "分散投資とリスク許容度",
  "category": ["分散投資"],
  "summary": "1〜2文の紹介文をここに書く。",
  "thumbnail": "",
  "instagram_url": "https://www.instagram.com/p/実際の投稿ID/",
  "status": "published"
}
```

- `category`: 配列。ここに書いた言葉がアーカイブのフィルターに自動で追加されます
- `thumbnail`: 空欄 `""` でもOK(その場合はグレーの枠が表示される)。画像を使う場合は `assets/thumbs/` に入れてパスを書く
- `instagram_url`: その回の投稿URL。まだ無ければプロフィールURLでも可
- `status`: `"published"`(公開) か `"upcoming"`(近日公開・半透明表示)

## 新しいNEWSを追加するには
`news.json` の配列の**先頭**に1件追記(新しいものが左に来ます)。

```json
{
  "tag": "日本株",
  "date": "2026-07-10",
  "summary": "見出しを1文で",
  "instagram_url": ""
}
```

- `date`: `YYYY-MM-DD` 形式で書くと、サイト側で自動的に `07/10 (木)` のように曜日付きで表示されます
- `instagram_url`: その回の投稿URLを入れるとカードがリンクになります。空欄 `""` ならリンクなしのカードになります

## 現在の状態・差し替え推奨
- 第1〜8回の `instagram_url` は実際の投稿URLを設定済み。第9回は近日公開のため空欄
- 各レクチャーの `thumbnail` は空欄で、番号+タイトルのデザイン枠が自動生成されて表示されます。Instagram投稿1枚目の画像を `assets/thumbs/` に入れてパスを設定すれば、その画像に差し替わります
- `news.json` は現在サンプル内容。実運用時に日々のNEWS見出しへ差し替えてください

## 将来の拡張(未実装)
`assets/app.js` の `fetchJSON` 関数が全データ取得の入り口です。将来Instagram Graph APIで
投稿を自動取得したくなった場合は、ここをAPI呼び出しに差し替えれば、HTML側は変更不要です。
（トークンの定期更新やサーバー処理が必要になるため、必要になった時点で別途実装してください）

## デザイン変更時の注意
- カラーは 赤#FF3333 / 緑#33CC66 / 黒#000000 / 白#FFFFFF のみ
- 白背景・グラデーション禁止・角丸あり・2px枠・ハードシャドウ が統一ルール
- 色やレイアウトは `assets/style.css` の先頭 `:root` の変数でまとめて管理
